package com.example.rockvibe.ui.buyer

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rockvibe.data.model.Order
import com.example.rockvibe.data.repository.AuthRepository
import com.example.rockvibe.data.repository.OrderRepository
import com.example.rockvibe.ui.location.LocationHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuyerCheckoutScreen(
    onBack: () -> Unit,
    onPaymentSuccess: () -> Unit
) {
    val context = LocalContext.current
    val cart by OrderRepository.cart.collectAsState()
    val currentUser by AuthRepository.currentUser.collectAsState()

    var shippingAddress by remember { mutableStateOf(currentUser?.address.takeIf { !it.isNullOrBlank() } ?: "Calle 80 # 45-12, Bogotá") }
    var currentLatitude by remember { mutableStateOf<Double?>(null) }
    var currentLongitude by remember { mutableStateOf<Double?>(null) }
    var isFetchingLocation by remember { mutableStateOf(false) }
    var locationError by remember { mutableStateOf<String?>(null) }

    var selectedPaymentMethod by remember { mutableStateOf("Tarjeta de Crédito / Débito") }
    var cardNumber by remember { mutableStateOf("4532 **** **** 8901") }
    var cardExpiry by remember { mutableStateOf("12/28") }
    var cardCvc by remember { mutableStateOf("321") }

    var isProcessing by remember { mutableStateOf(false) }
    var completedOrder by remember { mutableStateOf<Order?>(null) }

    val totalAmount = cart.sumOf { it.product.price * it.quantity }
    val scrollState = rememberScrollState()

    fun fetchGpsLocation() {
        isFetchingLocation = true
        locationError = null
        LocationHelper.getCurrentLocation(
            context = context,
            onSuccess = { locationData ->
                currentLatitude = locationData.latitude
                currentLongitude = locationData.longitude
                shippingAddress = locationData.address
                isFetchingLocation = false
            },
            onError = { errMsg ->
                locationError = errMsg
                isFetchingLocation = false
            }
        )
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            fetchGpsLocation()
        } else {
            locationError = "Se requieren permisos de ubicación para autocompletar tu dirección por GPS."
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Pasarela de Pagos & Envío") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Atrás")
                    }
                }
            )
        }
    ) { padding ->
        if (completedOrder != null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    modifier = Modifier.size(80.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text("¡Pago y Pedido Exitoso!", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Tu pedido ${completedOrder!!.id} ha sido procesado con éxito.")
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedCard(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Dirección de Envío a Domicilio:", fontWeight = FontWeight.Bold)
                        Text(completedOrder!!.shippingAddress)
                        if (completedOrder!!.latitude != null && completedOrder!!.longitude != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            AssistChip(
                                onClick = { },
                                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                                label = { Text("Coordenadas GPS: ${completedOrder!!.latitude}, ${completedOrder!!.longitude}") }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("Se envió la confirmación al correo: ${currentUser?.email}")
                Spacer(modifier = Modifier.height(24.dp))
                Button(onClick = onPaymentSuccess) {
                    Text("Volver a la Tienda")
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(scrollState)
            ) {
                Text(
                    text = "Resumen de Orden & Geolocalización de Envío",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = shippingAddress,
                    onValueChange = { shippingAddress = it },
                    label = { Text("Dirección de Envío a Domicilio") },
                    leadingIcon = { Icon(Icons.Default.LocalShipping, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = {
                        if (LocationHelper.hasLocationPermission(context)) {
                            fetchGpsLocation()
                        } else {
                            locationPermissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isFetchingLocation,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (isFetchingLocation) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Obteniendo ubicación GPS...")
                    } else {
                        Icon(Icons.Default.MyLocation, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Usar mi ubicación GPS actual")
                    }
                }

                if (currentLatitude != null && currentLongitude != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    "Geolocalización GPS fijada",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    "Lat: $currentLatitude, Lng: $currentLongitude",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                }

                if (locationError != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = locationError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Método de Pago",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                val paymentMethods = listOf("Tarjeta de Crédito / Débito", "PSE (Débito Bancario)", "Pago Contraentrega / Efectivo")
                paymentMethods.forEach { method ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedPaymentMethod == method,
                            onClick = { selectedPaymentMethod = method }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(method)
                    }
                }

                if (selectedPaymentMethod.startsWith("Tarjeta")) {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = cardNumber,
                        onValueChange = { cardNumber = it },
                        label = { Text("Número de Tarjeta") },
                        leadingIcon = { Icon(Icons.Default.CreditCard, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = cardExpiry,
                            onValueChange = { cardExpiry = it },
                            label = { Text("Exp (MM/YY)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = cardCvc,
                            onValueChange = { cardCvc = it },
                            label = { Text("CVC") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Total a Pagar:", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            text = "$${String.format("%.2f", totalAmount)}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        isProcessing = true
                        val order = OrderRepository.checkout(
                            buyerId = currentUser?.id ?: "u_buyer1",
                            buyerName = currentUser?.name ?: "Juan Pérez",
                            address = shippingAddress,
                            latitude = currentLatitude,
                            longitude = currentLongitude
                        )
                        completedOrder = order
                        isProcessing = false
                    },
                    enabled = !isProcessing && cart.isNotEmpty(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Icon(Icons.Default.Payment, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Confirmar y Pagar", fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
