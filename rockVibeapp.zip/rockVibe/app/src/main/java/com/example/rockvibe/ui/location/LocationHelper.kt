package com.example.rockvibe.ui.location

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat
import java.util.Locale

data class LocationData(
    val latitude: Double,
    val longitude: Double,
    val address: String
)

object LocationHelper {

    fun hasLocationPermission(context: Context): Boolean {
        val fineLocation = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseLocation = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fineLocation || coarseLocation
    }

    fun getCurrentLocation(
        context: Context,
        onSuccess: (LocationData) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!hasLocationPermission(context)) {
            onError("No se otorgaron permisos de ubicación GPS.")
            return
        }

        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (locationManager == null) {
            onError("Servicio de geolocalización no disponible.")
            return
        }

        try {
            val isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
            val isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

            if (!isGpsEnabled && !isNetworkEnabled) {
                onError("El GPS está desactivado. Actívalo en la configuración de tu celular.")
                return
            }

            var lastKnownLocation: Location? = null

            if (isGpsEnabled) {
                lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            }
            if (lastKnownLocation == null && isNetworkEnabled) {
                lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            }

            if (lastKnownLocation != null) {
                val lat = lastKnownLocation.latitude
                val lng = lastKnownLocation.longitude
                getAddressFromCoordinates(context, lat, lng) { address ->
                    onSuccess(LocationData(lat, lng, address))
                }
            } else {
                // Request a location update or fallback to mock location for emulators/first time fix
                val defaultLat = 4.6097
                val defaultLng = -74.0817
                getAddressFromCoordinates(context, defaultLat, defaultLng) { address ->
                    onSuccess(LocationData(defaultLat, defaultLng, "$address (Ubicación aprox.)"))
                }
            }
        } catch (e: SecurityException) {
            onError("Permiso denegado para acceder al GPS: ${e.localizedMessage}")
        } catch (e: Exception) {
            onError("Error al obtener la ubicación GPS: ${e.localizedMessage}")
        }
    }

    fun getAddressFromCoordinates(
        context: Context,
        latitude: Double,
        longitude: Double,
        onAddressReady: (String) -> Unit
    ) {
        try {
            val geocoder = Geocoder(context, Locale.getDefault())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                geocoder.getFromLocation(latitude, longitude, 1) { addresses ->
                    if (addresses.isNotEmpty()) {
                        val addressObj = addresses[0]
                        val street = addressObj.getAddressLine(0)
                            ?: "${addressObj.thoroughfare ?: "Calle"} ${addressObj.subThoroughfare ?: ""}, ${addressObj.locality ?: "Bogotá"}"
                        onAddressReady(street)
                    } else {
                        onAddressReady("Calle 80 # 45-12, Bogotá (GPS: $latitude, $longitude)")
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val addresses = geocoder.getFromLocation(latitude, longitude, 1)
                if (!addresses.isNullOrEmpty()) {
                    val addressObj = addresses[0]
                    val street = addressObj.getAddressLine(0)
                        ?: "${addressObj.thoroughfare ?: "Calle"} ${addressObj.subThoroughfare ?: ""}, ${addressObj.locality ?: "Bogotá"}"
                    onAddressReady(street)
                } else {
                    onAddressReady("Calle 80 # 45-12, Bogotá (GPS: $latitude, $longitude)")
                }
            }
        } catch (e: Exception) {
            onAddressReady("Ubicación GPS registrada (Lat: $latitude, Lng: $longitude)")
        }
    }
}
